﻿namespace Shapes
{
    public class Shapes
    {
        // задачите са много интересни, но нямам време
        // ако утре имам, ще ги довърша
    }
}
