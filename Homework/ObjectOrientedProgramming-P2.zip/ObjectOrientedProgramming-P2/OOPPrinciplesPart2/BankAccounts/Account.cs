﻿namespace BankAccounts
{
    public class Bank
    {
        // задачите са много интересни, но нямам време
        // ако утре имам, ще ги довърша
    }
}
