﻿namespace RangeExceptions
{
    public class InvalidRangeException<T>
    {
        // задачите са много интересни, но нямам време
        // ако утре имам, ще ги довърша
    }
}
