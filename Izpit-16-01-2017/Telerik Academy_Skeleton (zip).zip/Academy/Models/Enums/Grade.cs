﻿namespace Academy.Models.Enums
{
    public enum Grade
    {
    }
}
