﻿namespace Academy.Models.Enums
{
    public enum Grade
    {
        Failed = 2,
        Passed,
        Excellent
    }
}
