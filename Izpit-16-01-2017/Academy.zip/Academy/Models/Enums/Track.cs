﻿namespace Academy.Models.Enums
{
    public enum Track
    {
        None = 0,
        Frontend,
        Dev
    }
}
